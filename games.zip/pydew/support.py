import pygame
from os import walk

def import_folder(path):
	surface_list = []

	for _, __, img_files in walk(path):
		for image in img_files:
			full_path = path + '/' + image
			image_surf = pygame.image.load(full_path).convert_alpha()
			surface_list.append(image_surf)

	return surface_list

def import_frames(path,frames):
	frame_list = []
	for i in range(frames):
		surface = pygame.image.load(path + "/" + str(i) + ".png")
		frame_list.append(surface)
	return frame_list

def import_folder_dict(path):
	surface_dict = {}

	for _,__,files in walk(path):
		for file in files:
			surface_dict[file.split(".")[0]] = pygame.image.load(path + "/" +file).convert_alpha()

	return surface_dict