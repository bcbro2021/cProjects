import pygame

WIN_TITLE = "Testing Game"

WIN_WIDTH = 1280
WIN_HEIGHT = 720
TILE_SIZE = 64

OVERLAY_POSITIONS = {
	"tool": (40, WIN_HEIGHT - 15),
	"seed": (70, WIN_HEIGHT - 5)
}

LAYERS = {
	"water": 0,
	"ground": 1,
	"soil": 2,
	"soil water": 3,
	"rain floor": 4,
	"house bottom": 5,
	"ground plant": 6,
	"main": 7,
	"house top": 8,
	"fruit": 9,
	"rain drops": 10
}

APPLE_POS = {
	"Small": [(18, 17), (30, 37), (12, 50), (30,45), (20,30), (30, 10)],
	"Large": [(30, 24), (60, 65), (50, 50) , (16,40), (45, 50), (42,70)]
}

PLAYER_TOOL_OFFSET = {
	'left': pygame.math.Vector2(-50, 48),
	'right': pygame.math.Vector2(50, 40),
	'up': pygame.math.Vector2 (0, -10),
	'down': pygame.math.Vector2 (0, 50)
}

GROW_SPEED = {
	"corn": 1,
	"tomato": 0.7
}