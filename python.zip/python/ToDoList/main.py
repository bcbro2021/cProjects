import os, sys

try:
    os.mkdir(".data")
    os.chdir(".data")
except FileExistsError:
    os.chdir(".data")
    
if sys.argv[1] == "add":
    with open("to.do","a") as file:
        file.write(sys.argv[2]+"\n")
elif sys.argv[1] == "remove":
    lines = None
    with open("to.do","r") as file:
        lines = file.readlines()
    #remove stuff
    appendIndex = []
    for i in range(len(lines)):
        lines[i] = lines[i].split("\n")[0]
        if sys.argv[2] == lines[i]:
            pass
        else:
            appendIndex.append(lines[i])
    #write to file
    open("to.do","w").close()
    for i in range(len(appendIndex)):
        with open("to.do","a") as file:
            file.write(appendIndex[i]+"\n")
elif sys.argv[1] == "list":
    with open("to.do", "r") as file:
        data = file.readlines()
        for i in range(len(data)):
            print(data[i].split("\n")[0])
else:
    print("Unknown Command!")
    sys.exit()
