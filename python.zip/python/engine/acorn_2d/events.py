import pygame
import sys
from .exceptions import *
from pygame.locals import *

#keys
kA = K_a
kB = K_b
kC = K_c
kD = K_d
kE = K_e
kF = K_f
kG = K_g
kH = K_h
kI = K_i
kJ = K_j
kK = K_k
kL = K_l
kM = K_m
kN = K_n
kO = K_o
kP = K_p
kQ = K_q
kR = K_r
kS = K_s
kT = K_t
kU = K_u
kV = K_v
kW = K_w
kX = K_x
kY = K_y
kZ = K_z
kComma = K_COMMA

#numbers
k0 = K_0
k1 = K_1
k2 = K_2
k3 = K_3
k4 = K_4
k5 = K_5
k6 = K_6
k7 = K_7
k8 = K_8
k9 = K_9

#left function keys
kLCtrl = K_LCTRL
kLShift = K_LSHIFT
kLAlt = K_LALT
kLeft = K_LEFT
kLBracket = K_LEFTBRACKET
kLParen = K_LEFTPAREN

#right function keys
kRCtrl = K_RCTRL
kRShift = K_RSHIFT
kRAlt = K_RALT
kRight = K_RIGHT
kRBracket = K_RIGHTBRACKET
kRParen = K_RIGHTPAREN

#events
#event List
def getEvents():
    try:
        return pygame.event.get()
    #get events error checking
    except Exception:
        raise EventListError("Failed to get Events.")
#key down
def keyDown(event,key):
    try:
        returnStat = False
        if event.type == KEYDOWN:
            if event.key == key:
                returnStat = True
        return returnStat
    #key down event error checking
    except Exception:
        raise KeyDownError("Failed to detect key down.")

#key up
def keyUp(event,key):
    try:
        returnStat = False
        if event.type == KEYUP:
            if event.key == key:
                returnStat = True
        return returnStat
    #key up event error checking
    except Exception:
        raise KeyUpError("Failed to detect key up.")

#key press
def keyPressed(key):
    try:
        returnStat = False
        keys=pygame.key.get_pressed()
        if keys[key]:
            returnStat = True
        return returnStat
    #key press event error checking
    except Exception:
        raise KeyPressedError("Failed to detect key press.")

#mouse press
def mousePressed(mouse_index=0):
    try:
        return pygame.mouse.get_pressed()[mouse_index]
    #mouse press event error checking
    except Exception:
        raise MousePressedError("Failed to detect mouse press.")

#quit event
def QuitEvent(event):
    try:
        returnStat = False
        if event.type == QUIT:
            returnStat = True
        return returnStat
    #quit event error checking
    except Exception:
        raise QuitEventError("Failed to detect quit event.")