import os
#pygame text delete
os.environ['PYGAME_HIDE_SUPPORT_PROMPT'] = '1'
import pygame
from .exceptions import *

class Acorn:
    #initialization
    def __init__(self,size=(800,600)):
        #pygame init
        pygame.init()
        #brussels init
        print("Acorn 2d Initialized!")
        print("----------------------------")
        #window creation
        #window args
        try:
            self.title = "Acorn 2d Window"
            self.clock = pygame.time.Clock()
            self.fps = 60
            self.icon = ""
            self.win = pygame.display.set_mode(size)
            pygame.display.set_caption(self.title)
            print(f"Window Resolution: {size}")
        #window init error checking
        except Exception:
            raise WindowCreationError("Failed to create Window.")
    #window set title
    def setTitle(self,title):
        try:
            self.title = title
            pygame.display.set_caption(self.title)
        #window set Title error checking
        except Exception:
            raise WindowNamingError("Failed to name Window.")
    #window set icon
    def setIcon(self,path):
        try:
            self.icon = pygame.image.load(path)
            pygame.display.set_icon(self.icon)
        #window set icon error checking
        except FileNotFoundError:
            raise ImageNotLoadedError("Failed to set icon.")
    #window update
    def update(self):
        pygame.display.update()
    #window fill
    def fill(self,color=(0,0,0)):
        try:
            self.win.fill(color)
        #window fill error checking
        except Exception:
            raise WindowFillError("Failed to fill Window.")
    #set fps
    def setFPS(self,fps=60):
        try:
            self.fps = fps
            self.clock.tick(self.fps)
        #window set fps error checking
        except Exception:
            raise WindowFPSError("Failed to set FPS.")
    #get fps
    def getFPS(self):
        try:
            return self.clock.tick(self.fps)
        #window get fps error checking
        except Exception:
            raise WindowFPSError("Failed to get FPS.")
