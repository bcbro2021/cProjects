import pygame
import sys
from .exceptions import *

class GameSprite:
    #initialization for rects and sprite
    def __init__(self,pos=(400,300),scale=(20,20),color=(255,0,0),displayRect=True):
        #positions
        self.x = pos[0]
        self.y = pos[1]
        #color
        self.color = color
        #collision stuff
        self.width = scale[0]
        self.height = scale[1]
        #states for display
        self.displayRect = displayRect
        self.displayingTex = False
        self.displayingAnimation = False
        #animation
        self.action = ""
        self.frame = 0
        self.flip = False
        self.animation_frames = {}
        self.animation_database = {}
        #init
        try:
            self.rect = pygame.Rect(self.x,self.y,self.width,self.height)
        #sprite creation error checking
        except Exception():
            raise SpriteCreationError("Failed to create Sprite.")
    #update pos and draw
    def update(self,display):
        #display sprite rect
        try:
            if self.displayRect:
                pygame.draw.rect(display.win,self.color,self.rect)
        #sprite render error checking
        except Exception:
            raise SpriteRenderError("Failed to render Sprite.")
        #update rect pos
        try:
            self.rect.x = self.x
            self.rect.y = self.y
        #sprite update error checking
        except Exception:
            raise SpriteUpdateError("Failed to update Sprite.")
    #get collider
    def getRect(self):
        return self.rect()
    #display a texture
    def displayTexture(self,display,img,setRectScaleToTextureScale):
        try:
            if not self.displayAnimation:
                display.win.blit(pygame.transform.flip(img,self.flip,False),(self.rect.x,self.rect.y))
                if setRectScaleToTextureScale:
                    self.rect.width = img.get_width()
                    self.rect.height = img.get_height()
                self.displayingTex = True
            else:
                print("Disable 'displayAnimation()' to display the Texture")
                sys.exit()
        #sprite texture render error checking
        except Exception:
            raise SpriteRenderError("Failed to display Sprite Texture.")
    #collision with sprite
    def collideSprite(self,Sprite):
        try:
            return self.rect.colliderect(Sprite.rect)
        #sprite collision error checking
        except Exception:
            raise SpriteCollisionError("Failed to run Collision tests.")
    #checks if sprite has been clicked on
    def clicked(self,event):
        try:
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.rect.collidepoint(event.pos):
                    return True
        #sprite mouse click error checking
        except Exception:
            raise SpriteClickedError("Failed to detect mouse click.")
    #animation loader
    def loadAnimation(self,name,path,frame_durations):
        try:
            animation_name = path.split("/")[-1]
            animation_frame_data = []
            n = 0
            for frame in frame_durations:
                animation_frame_id = animation_name + "_" + str(n)
                img_loc = path + "/" + animation_frame_id + ".png"
                animation_image = pygame.image.load(img_loc)
                self.animation_frames[animation_frame_id] = animation_image.copy()
                for i in range(frame):
                    animation_frame_data.append(animation_frame_id)
                n += 1
            self.animation_database[name] = animation_frame_data
        #sprite load animation error checking
        except Exception:
            raise SpriteLoadError("Failed to load Animation.")
    #animation display
    def displayAnimation(self,display,name,setRectScaleToTextureScale):
        try:
            if self.action != name:
                self.action = name
                self.frame = 0
            self.frame += 1
            if self.frame >= len(self.animation_database[self.action]):
                self.frame = 0
            sprite_img_id = self.animation_database[self.action][self.frame]
            img = self.animation_frames[sprite_img_id]
            if not self.displayingTex:
                display.win.blit(pygame.transform.flip(img,self.flip,False),(self.x,self.y))
                if setRectScaleToTextureScale:
                    self.rect.width = img.get_width()
                    self.rect.height = img.get_height()
                self.displayingAnimation = True
            else:
                print("Disable 'displayTexture()' to display the animation")
                sys.exit()
        #sprite render animation error checking
        except Exception:
            raise SpriteRenderError("Failed to display Animation.")