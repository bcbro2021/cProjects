import pygame
from .exceptions import *

#image loading
def loadImage(path):
    try:
        return pygame.image.load(path)
    #image load error checking
    except Exception:
        raise ImageNotLoadedError("Failed to load Image.")

#image drawing
def drawImage(display,img,pos):
    try:
        display.win.blit(img,pos)
    #image draw error checking
    except Exception:
        raise ImageNotRenderedError("Failed to draw Image.")

#asset loader
def loadAssets(path):
    try:
        returnStat = []
        with open(path, "r") as file:
            data = file.readlines()
            for line in data:
                img = loadImage(line)
                returnStat.append(img)
        return returnStat
    #image load for assets file error checking
    except Exception:
        raise ImageLoadAssetsError("Failed to load assets file.")
