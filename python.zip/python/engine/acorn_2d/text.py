import pygame
from .exceptions import *

class Text():
	def __init__(self,text="text",pos=(20,20),bcolor=(0,0,0),fcolor=(255,255,255),font='freesansbold.ttf',fontSize=12):
		#args
		self.x = pos[0]
		self.y = pos[1]
		self.text = text
		self.font = font
		self.fcolor = fcolor
		self.bcolor = bcolor
		self.fontSize = fontSize
		self.frame = 0
		self.animation = []
		self.animationDelay = 0
		#text init display
		try:
			self.fontInit = pygame.font.Font(self.font, self.fontSize)
			self.textDis = self.fontInit.render(self.text, True, self.fcolor, self.bcolor)
			self.textRect = self.textDis.get_rect()
			self.textRect.center = (self.x, self.y)
		#text creation error checking
		except Exception:
			raise TextCreationError("Failed to create text.")
	def update(self,display):
		try:
			#updating position, text and font with font Size
			self.fontInit = pygame.font.Font(self.font, self.fontSize)
			self.textDis = self.fontInit.render(self.text, True, self.fcolor, self.bcolor)
			self.textRect.center = (self.x, self.y)
			#displaying text
			display.win.blit(self.textDis,self.textRect)
		#text update error checking
		except Exception:
			raise TextUpdateError("Failed to update text.")
	#set animation
	def setAnimation(self,animation):
		self.animation = animation
	#display animation
	def displayAnimation(self,delay):
		try:
			self.animationDelay -= 1
			if self.animationDelay <= 0:
				self.text = self.animation[self.frame]
				if self.frame < len(self.animation)-1:
					self.frame += 1
				else:
					self.frame = 0
				self.animationDelay = delay
		#text display animation error checking
		except Exception:
			raise TextRenderError("Failed to render animation.")
			