#main window errors
class WindowCreationError(Exception):
	__module__ = "builtins"

class WindowNamingError(Exception):
	__module__ = "builtins"

class WindowFillError(Exception):
	__module__ = "builtins"

class WindowFPSError(Exception):
	__module__ = "builtins"

#image errors
class ImageNotLoadedError(Exception):
	__module__ = "builtins"

class ImageNotRenderedError(Exception):
	__module__ = "builtins"

class ImageLoadAssetsError(Exception):
	__module__ = "builtins"

#sprite errors
class SpriteCreationError(Exception):
	__module__ = "builtins"

class SpriteRenderError(Exception):
	__module__ = "builtins"

class SpriteUpdateError(Exception):
	__module__ = "builtins"

class SpriteCollisionError(Exception):
	__module__ = "builtins"

class SpriteClickedError(Exception):
	__module__ = "builtins"

class SpriteLoadError(Exception):
	__module__ = "builtins"

#text errors
class TextCreationError(Exception):
	__module__ = "builtins"

class TextUpdateError(Exception):
	__module__ = "builtins"

class TextRenderError(Exception):
	__module__ = "builtins"

#events errors
class EventListError(Exception):
	__module__ = "builtins"

class KeyDownError(Exception):
	__module__ = "builtins"

class KeyUpError(Exception):
	__module__ = "builtins"

class KeyPressedError(Exception):
	__module__ = "builtins"

class MousePressedError(Exception):
	__module__ = "builtins"

class QuitEventError(Exception):
	__module__ = "builtins"