import sys

from acorn_2d import *

app = Acorn(size=(800,600))

#load image
img = loadImage("acorn_2d/acorn_2d.png")
#player
sprite = GameSprite()
sprite.displayRect = False
moveRight = False
moveLeft = False
moveUp = False
moveDown = False
sprite.loadAnimation("idle","idle",(5,5,5))
sprite.loadAnimation("run","run",(2,2))

#rect to collide with
sprite2 = GameSprite(pos=(500,300))
#text
text = Text(text="")
text.setAnimation(["load.","load..","load...","load...."])
while True:
    #background
    app.fill()
    #player
    sprite.update(app)
    text.displayAnimation(20)
    #movement
    if moveUp:
        sprite.y -= 6
    if moveDown:
        sprite.y += 6
    if moveRight:
        sprite.flip = False
        sprite.displayAnimation(app,"run",True)
        sprite.x += 6
    elif moveLeft:
        sprite.flip = True
        sprite.displayAnimation(app,"run",True)
        sprite.x -= 6
    else:
        sprite.displayAnimation(app,"idle",True)

    #rect to collide with
    sprite2.update(app)
    if sprite.collideSprite(sprite2):
        print("Hello world")
    #text display
    text.update(app)
    text.x += 1
    #events
    for event in getEvents():
        if QuitEvent(event):
            sys.exit()
        if keyDown(event,kW):
            moveUp = True
        if keyDown(event,kA):
            moveLeft = True
        if keyDown(event,kS):
            moveDown = True
        if keyDown(event,kD):
            moveRight = True
        if keyUp(event,kW):
            moveUp = False
        if keyUp(event,kA):
            moveLeft = False
        if keyUp(event,kS):
            moveDown = False
        if keyUp(event,kD):
            moveRight = False
    #game display update
    app.update()
    app.setFPS(60)