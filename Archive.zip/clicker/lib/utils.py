import random

def generate_random_name(names,ends):
	with open(names,"r") as file:
		namesdat = file.readlines()
	with open(ends,"r") as file:
		endsdat = file.readlines()

	name = namesdat[random.randint(0,len(namesdat)) - 1].strip() + " " + endsdat[random.randint(0,len(endsdat)) - 1].strip()
	return name

def percent(x, y):
    p = x / y * 100
    return int(p)