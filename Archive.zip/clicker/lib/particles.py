import pygame, random, lib
from pygame import gfxdraw

class Particle:
	def __init__(self):
		self.particles = []

	def emit(self,win):
		if self.particles:
			self.delete()
			for particle in self.particles:
				# move
				particle[0][0] += random.randint(particle[2][0][0],particle[2][0][1])
				particle[0][1] += random.randint(particle[2][1][0],particle[2][1][1])

				# gravity
				particle[5] += 0.2
				particle[0][1] += particle[5]

				# shrink
				particle[1] -= particle[4]

				# draw
				#gfxdraw.filled_circle(win, int(particle[0][0]), int(particle[0][1]), int(particle[1]), particle[3])
				#gfxdraw.aacircle(win, int(particle[0][0]), int(particle[0][1]), int(particle[1]), particle[3])
				pygame.draw.circle(win, particle[3], particle[0], int(particle[1]))

	def add(self,x,y,r,dx,dy,c,shrink_speed=0.2):
		pos_x = x
		pos_y = y
		radius = r
		directionx = dx
		directiony = dy
		color = c
		particle_y_momentum = 0
		particle_circle = [[pos_x,pos_y],
							radius,
							[directionx,directiony],
							color,
							shrink_speed,
							particle_y_momentum]

		self.particles.append(particle_circle)

	def delete(self):
		particle_copy = [particle for particle in self.particles if particle[1] > 0]
		self.particles = particle_copy

class TextParticle():
	def __init__(self):
		self.particles = []

	def emit(self,win):
		if self.particles:
			self.delete()
			for particle in self.particles:
				# move
				particle[0].rect.x += random.randint(particle[1][0][0], particle[1][0][1])
				particle[0].rect.y += random.randint(particle[1][1][0], particle[1][1][1])

				# gravity
				particle[3] += 0.2
				particle[0].rect.y += particle[3]

				# shrink
				particle[0].rect.width -= particle[2]
				particle[0].rect.height -= particle[2]

				# draw
				particle[0].draw(win)


	def add(self,text,x,y,size,dx,dy,fc,shrink_speed=0.2):
		directionx = dx
		directiony = dy
		par_text = lib.Text(text, x, y, size, fc)
		particle_y_momentum = 0
		particle_text = [par_text,
						[directionx,directiony],
						shrink_speed,
						particle_y_momentum]
		self.particles.append(particle_text)
		

	def delete(self):
		particle_copy = [particle for particle in self.particles if particle[0].rect.width > 0]
		self.particles = particle_copy