import pygame

class Entity():
	def __init__(self,x,y,w,h,c,image="none"):
		self.x = x
		self.y = y
		self.w = w
		self.h = h
		self.c = c
		self.image = None
		if image != "none":
			self.image = pygame.image.load(image)
		self.rect = pygame.Rect(self.x,self.y,self.w,self.h)

		# animation stuff
		self.animations = {}
		self.frame = 0
		self.max_frames = 0
		self.current_animation_name = "none"
		self.repeat_current_animation = False

	def draw(self,win):
		if self.image != None:
			win.blit(self.image,(self.x,self.y))
		else:
			pygame.draw.rect(win,self.c,self.rect)

	def new_animation(self,name,frames):
		images = []
		for frame in frames:
			images.append(pygame.image.load(frame))

		self.animations[name] = images

	def current_animation(self,name,repeat=False):
		self.frame = 0
		self.max_frames = len(self.animations[name]) - 1
		self.current_animation_name = name
		self.repeat_current_animation = repeat

	def drawable_frames(self):
		return self.animations[self.current_animation_name][self.frame]

	def set_image(self, image):
		self.image = pygame.image.load(image)

	def update(self):
		self.rect.x = self.x
		self.rect.y = self.y
		self.rect.width = self.w
		self.rect.height = self.h

	def clicked_on(self, event):
		returnstat = False
		if event.type == pygame.MOUSEBUTTONDOWN:
			if event.button == pygame.BUTTON_LEFT:
				pos = pygame.mouse.get_pos()
				if self.rect.collidepoint(pos[0], pos[1]):
					returnstat = True

		return returnstat