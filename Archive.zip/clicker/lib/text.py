import pygame

class Text():
	def __init__(self,text,x,y,size,fc,font="freesansbold.ttf"):
		self.x = x
		self.y = y
		self.size = size
		self.font = font
		self.text = text
		self.fc = fc

		self.tfont = pygame.font.Font(self.font, self.size)
		self.ttext = self.tfont.render(self.text, True, self.fc)
		self.rect = self.ttext.get_rect()
		self.rect.center = (x,y)

	def draw(self,win):
		win.blit(self.ttext,self.rect)

	def update_text(self,text):
		self.text = text
		self.ttext = self.tfont.render(self.text, True, self.fc)