import pygame
import lib

class Boss(lib.Entity):
	def __init__(self,x,y,w,h,c):
		super().__init__(x,y,w,h,c)
		self.max_health = 100
		self.health = self.max_health
		self.health_modifier = 1
		# boss healthbar and title
		self.healthbar = lib.Entity(self.x+150, 250, lib.percent(self.health,self.max_health) * 2, 20, (255,100,100))
		self.titlebar = lib.Text(lib.generate_random_name("lib/bossnames", "lib/bossnameends"), self.x+250, 220, 25, (255,255,255))
		self.healthbar_text = lib.Text(str(self.health), self.x+200, 260, 10, (0,0,0))