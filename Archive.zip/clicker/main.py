import pygame, sys, lib, random
from pygame.locals import *
pygame.init()

# CONSTS
TITLE = "title"
WIN_SIZE = (800,600)
MAX_FPS = 60

# events
HERO_IDLE_ANIM_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(HERO_IDLE_ANIM_EVENT, 100)

HERO_ATTACK_ANIM_EVENT = pygame.USEREVENT + 2
pygame.time.set_timer(HERO_ATTACK_ANIM_EVENT, 20)

BOSS_IDLE_ANIM_EVENT = pygame.USEREVENT + 1
pygame.time.set_timer(BOSS_IDLE_ANIM_EVENT, 100)

BOSS_DAMAGE_ANIM_EVENT = pygame.USEREVENT + 2
pygame.time.set_timer(BOSS_DAMAGE_ANIM_EVENT, 50)


# window
win = pygame.display.set_mode(WIN_SIZE)
pygame.display.set_caption(TITLE)
clock = pygame.time.Clock()

# hero
hero_w = 20
hero_h = 35
hero_damage = 10
hero_damage_modifier = 1
hero = lib.Entity(WIN_SIZE[0]/2-100,WIN_SIZE[1]-100,hero_w,hero_h,(20,20,20))
hero.set_image("assets/hero1.png")
hero_upgrade_btn = lib.Entity(10, 50, 50, 20, (50,50,50))
hero_upgrade_price = 100
hero_upgrade_price_modifier = 1

# hero animations
hero.new_animation("idle", ["assets/hero/idle/0.png","assets/hero/idle/1.png","assets/hero/idle/2.png","assets/hero/idle/3.png"]) # idle
hero.new_animation("attack", ["assets/hero/attack/0.png","assets/hero/attack/1.png","assets/hero/attack/2.png","assets/hero/attack/3.png","assets/hero/attack/4.png","assets/hero/attack/5.png"]) # attack
hero.current_animation("idle",repeat=True)

# boss
boss_w = 550
boss_h = 400
boss = lib.Boss(WIN_SIZE[0]/2-150,WIN_SIZE[1]-460,boss_w,boss_h,(100,100,100))
boss.set_image("assets/boss1.png")


# boss animations
boss.new_animation("idle", ["assets/boss/idle/0.png","assets/boss/idle/1.png","assets/boss/idle/2.png","assets/boss/idle/3.png","assets/boss/idle/4.png","assets/boss/idle/5.png"])
boss.new_animation("damage", ["assets/boss/damage/0.png","assets/boss/damage/1.png","assets/boss/damage/2.png","assets/boss/damage/3.png","assets/boss/damage/4.png"])
boss.current_animation("idle",repeat=True)

# level up stuff
boss_defeat_count = 0
stage_level_up = 10

# currency system
money = 0
money_rate_modifier = 0.2
balance_display = lib.Text(f"Money: {str(money)}", 50, 20, 20, (100,100,100))

# particles
damage_display_particles = lib.TextParticle()
money_increase_display_particles = lib.TextParticle()

while True:
	# background
	win.fill((0,0,0))

	# draw boss
	win.blit(pygame.transform.scale(boss.drawable_frames(), (boss_w,boss_h)), (boss.x,boss.y))

	# draw hero
	win.blit(hero.drawable_frames(), (hero.x,hero.y))

	# draw titlebar
	boss.titlebar.draw(win)

	# draw healthbar
	boss.healthbar.draw(win)

	# draw healthbar text
	boss.healthbar_text.draw(win)

	# balance display
	balance_display.draw(win)

	# hero upgrade button
	hero_upgrade_btn.draw(win)

	# particles
	money_increase_display_particles.emit(win)
	damage_display_particles.emit(win)

	# events
	for event in pygame.event.get():
		if event.type == QUIT:
			pygame.quit()
			sys.exit()

		# hero upgrade
		if hero_upgrade_btn.clicked_on(event):
			if money >= hero_upgrade_price:
				# payment
				money -= hero_upgrade_price

				# damage increaser increase
				hero_damage_modifier += 0.5

				# damage increase
				hero_damage += hero_damage_modifier

				# price increase
				hero_upgrade_price += hero_upgrade_price_modifier
				hero_upgrade_price_modifier += 0.2
				print(hero_upgrade_price, hero_damage_modifier)

		# damaging
		if event.type == MOUSEBUTTONUP:
			# money collection
			money_increase_display_particles.add(str(round(money_rate_modifier,3)), boss.x + boss.w / 2, boss.y*2+100, 20, (-10,10), (-10,10), (207,181,59))
			money += money_rate_modifier
			money = round(money,2)
			balance_display.update_text(f"Money: {str(money)}")

			hero.current_animation("attack",repeat=False)
			boss.current_animation("damage",repeat=False)
			# cursor particles

			# damage
			damage_display_particles.add(str(hero_damage), boss.x + boss.w / 2, boss.y*2+100, 20, (-10,10), (-10,10), (255,10,10))
			boss.health -= hero_damage
			boss.healthbar_text.update_text(str(boss.health))
			boss.healthbar.w = lib.percent(boss.health,boss.max_health) * 2

		# animations
		# hero animations
		if hero.current_animation_name == "idle":
			if event.type == HERO_IDLE_ANIM_EVENT:
				if hero.frame < hero.max_frames:
					hero.frame += 1
				else:
					if hero.repeat_current_animation:
						hero.frame = 0
					else:
						hero.current_animation("idle",repeat=True)

		if hero.current_animation_name == "attack":
			if event.type == HERO_ATTACK_ANIM_EVENT:
				if hero.frame < hero.max_frames:
					hero.frame += 1
				else:
					if hero.repeat_current_animation:
						hero.frame = 0
					else:
						hero.current_animation("idle",repeat=True)

		# boss animations
		if boss.current_animation_name == "idle":
			if event.type == BOSS_IDLE_ANIM_EVENT:
				if boss.frame < boss.max_frames:
					boss.frame += 1
				else:
					if boss.repeat_current_animation:
						boss.frame = 0
					else:
						boss.current_animation("idle",repeat=True)

		if boss.current_animation_name == "damage":
			if event.type == BOSS_DAMAGE_ANIM_EVENT:
				if boss.frame < boss.max_frames:
					boss.frame += 1
				else:
					if boss.repeat_current_animation:
						boss.frame = 0
					else:
						boss.current_animation("idle",repeat=True)

	# update
	hero.update()
	boss.update()
	boss.healthbar.update()

	# boss level up
	if boss_defeat_count >= stage_level_up:
		boss.health_modifier = boss.health_modifier + 0.5
		boss_defeat_count = 0

	# boss changing
	if boss.health <= 0:
		# money rate increase
		money_rate_modifier += 0.1
		# level up
		boss_defeat_count += 1
		#print(boss_defeat_count)

		# name change
		boss_name = lib.generate_random_name("lib/bossnames", "lib/bossnameends")
		boss.titlebar.update_text(boss_name)

		# health change
		boss.max_health = random.randint(50 * boss.health_modifier,100 * boss.health_modifier)
		boss.health = boss.max_health
		boss.c = (random.randint(0,255),random.randint(0,255),random.randint(0,255))

	pygame.display.update()
	clock.tick(MAX_FPS)