import pygame, lib, sys
from pygame.locals import *
pygame.init()

class ToDo(lib.Entity):
	def __init__(self,x,y,w,h,c):
		super().__init__(x, y, w, h, c)
		self.selected = False
		self.done = False
		self.text = lib.Text("hello!", x, y, 10, (10,10,10))

	def draw(self,win):
		if self.image != None:
			win.blit(self.image,(self.x,self.y))
		else:
			if self.done:
				pygame.draw.rect(win,(100,255,100),self.rect)
				self.text.draw(win)
			else:
				pygame.draw.rect(win,(255,100,100),self.rect)
				self.text.draw(win)
	def update(self):
		self.rect.x = self.x
		self.rect.y = self.y
		self.rect.width = self.w
		self.rect.height = self.h
		self.text.rect.x = self.x + self.text.rect.width /2
		self.text.rect.y = self.y + self.text.rect.height /2
	def right_clicked(self,event):
		if event.type == MOUSEBUTTONDOWN:
			if event.button == BUTTON_RIGHT:
				pos = pygame.mouse.get_pos()
				if self.rect.collidepoint(pos[0], pos[1]):
					Input = input(">>")
					self.text.update_text(Input)
	def middle_clicked(self,event):
		if event.type == MOUSEBUTTONDOWN:
			if event.button == BUTTON_MIDDLE:
				pos = pygame.mouse.get_pos()
				if self.rect.collidepoint(pos[0], pos[1]):
					if self.done:
						self.done = False
					else:
						self.done = True

# window
win = pygame.display.set_mode((800,600),RESIZABLE)
pygame.display.set_caption("To Do List!")

# add button
add_btn = lib.Entity((win.get_width()/2)-25, 20, 50, 35, (255,255,255))
add_btn_txt = lib.Text("ADD!", win.get_width(), 70, 10, (0,0,0))

# delete_area
delete_area = lib.Entity(20, win.get_height()-20, 20, 20, (20,20,20))

todos = []
# reading the save file to display the list
with open("save.txt", "r") as file:
	data = file.readlines()
	for line in data:
		linedata = line.strip().split(",")
		todo = ToDo(int(float(linedata[1])), int(float(linedata[2])), 100, 50, (100,100,100))
		if linedata[3] == "False":
			todo.done = False
		else:
			todo.done = True
		todo.text.update_text(linedata[0])
		todos.append(todo)


# saving the changes
def save():
	with open("save.txt","w") as file:
		file.write("")
	for todo in todos:
		with open("save.txt", "a") as file:
			file.write(f"{todo.text.text},{todo.x},{todo.y},{todo.done}\n")

while True:
	# drawing
	win.fill((0,0,0))

	#draw todos
	if todos:
		for todo in todos:
			todo.draw(win)

	# add btn
	add_btn.draw(win)
	add_btn_txt.draw(win)

	# delete_area
	delete_area.draw(win)

	# events
	for event in pygame.event.get():
		if event.type == QUIT:
			save()
			pygame.quit()
			sys.exit()

		# add btn stuff
		if add_btn.clicked_on(event):
			todo = ToDo(win.get_width()/2, win.get_height()/2, 100, 50, (100,100,100))
			todos.append(todo)

		if todos:
			for todo in todos:
				todo.right_clicked(event)
				todo.middle_clicked(event)
				if todo.clicked_on(event):
					if todo.selected:
						todo.selected = False
					else:
						todo.selected = True
	# update add button
	add_btn.x = (win.get_width()/2)-25
	add_btn_txt.rect.x = win.get_width()/2
	add_btn.update()

	# update delete area
	delete_area.y = win.get_height()-20
	delete_area.update()

	# update todos
	for todo in todos:
		if todo.selected:
			pos = pygame.mouse.get_pos()
			todo.x = pos[0] - todo.w /2
			todo.y = pos[1] - todo.h /2
		if todo.collided_with(delete_area):
			todos.remove(todo)
			continue
		todo.update()
	# update
	pygame.display.update()