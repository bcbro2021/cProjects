--basic hello world
hello = "hello there"
print(hello)

--basic list
list = {1,2,3,4,5}
for v in pairs(list) do
    print(list[v])
end

--strings
hello = "testing world"
multilinestring = [[
    <html>
        <head>
            <title></title>
        </head>
    </html>
]]

--string concatenation
print("a" .. "b")
print(1234 .. 5678)

--length of string
hello = "hello"
print(#hello)

--functions and if statements
function printNum(num)
    if num == 0 then
        return 0
    else
        print(num)
    end
end

printNum(56)

--while loop
loopnum = 0
while (loopnum < 500) do
    loopnum = loopnum + 1
    print(loopnum)
end

--for loop
--prints the value numbers
list2 = {"Hello","World"}--1 and 2
for v in pairs(list2) do
    print(v)
end
--just normal for loop
for i=2,10,2 do
    print(i)
end

--iterate and print all values in list2
for i,v in ipairs(list2) do
    print(v)
end

--cool looping (better than while loops maybe)
numtest2 = 0
repeat
    numtest2 = numtest2 + 1
    print(numtest2)
until numtest2 == 500