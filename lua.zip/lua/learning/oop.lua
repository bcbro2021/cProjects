-- class
Funcs = {}

-- Derived class method print
function Funcs:Print(text)
    print(text)
end
-- Derived class method input
function Funcs:Input(text)
    io.write(text)
    return io.read()
end