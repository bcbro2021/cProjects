function Input(text)
    io.write(text)
    return io.read()
end
--code
while (true) do
    MainInput = Input("Operator > ")
    if MainInput == "+" then
        Num1 = Input("num1 > ")
        Num2 = Input("num2 > ")
        print("result: "..Num1+Num2)
    elseif MainInput == "-" then
        Num1 = Input("num1 > ")
        Num2 = Input("num2 > ")
        print("result: "..Num1-Num2)
    elseif MainInput == "/" then
        Num1 = Input("num1 > ")
        Num2 = Input("num2 > ")
        print("result: "..Num1/Num2)
    elseif MainInput == "*" then
        Num1 = Input("num1 > ")
        Num2 = Input("num2 > ")
        print("result: "..Num1*Num2)
    else
        print("Unknown operator.")
        break
    end
end