f = require("files")

file = f
print(file.read())