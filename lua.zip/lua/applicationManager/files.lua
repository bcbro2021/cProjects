-- File System class
Filesys = {file = "test.txt"}
-- File System read Function
function Filesys.read()
    arr = {}
    for line in io.lines(Filesys.file) do
        table.insert(arr,line)
    end
    append = ""
    for linenum, line in ipairs(arr) do
        append = append..line.."\n"
    end
    return append
end
-- File System readlines function
function Filesys.readlines()
    append = {}
    for line in io.lines(Filesys.file) do
        table.insert(append,line)
    end
    return append
end
-- File System append function
function Filesys.append(data)
    file = io.open(Filesys.file,"a")
    io.output(file)
    io.write(data)
    io.close(file)
end
--File System write function
function Filesys.write(data)
    file = io.open(Filesys.file,"w")
    io.output(file)
    io.write(data)
    io.close(file)
end

return Filesys