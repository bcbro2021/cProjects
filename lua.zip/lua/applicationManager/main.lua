fl = require("files")

function Input(text)
    io.write(text)
    return io.read()
end

local mainfile = fl
mainfile.file = "saves.txt"
local data = mainfile.readlines()
local names = {}
local execs = {}
for linenum in ipairs(data) do
    if string.find(data[linenum],"name:") then
        table.insert(names,string.sub(data[linenum],6,-1))
    end
    if string.find(data[linenum],"exec:") then
        table.insert(execs,string.sub(data[linenum],6,-1))
    end
end
while (true) do
    for linenum in ipairs(names) do
        print(linenum..": "..names[linenum])
    end
    local input = Input("> ")
    os.execute(execs[tonumber(input)])
end