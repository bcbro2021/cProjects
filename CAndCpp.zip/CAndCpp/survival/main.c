#include "include/lib.h"
#include "include/items.h"
#include "include/constants.h"
#define MAX_INPUT_CHAR 64

int run = 1;

// main function
int main(int argc,char* argv[]) 
{
    // max input range
    char input[MAX_INPUT_CHAR];

    // inventory system
    int inventory[10] = {};
    int inventoryCount[10] = {};

    while (run) 
    {
        // input
        printf("> ");
        fgets(input,MAX_INPUT_CHAR,stdin);

        // commands
        // loot
        if (charCmp(input,"loot"))
        {
            // random num seed
            srand(time(NULL));
            // loot id
            int lootid;
            int lootidArr[] = {};
            // loot count
            int lootcount;
            int lootcountArr[] = {};

            for (int i = 0;i < BASIC_LOOT_ID_COUNT;i++)
            {
                // loot gen
                lootid = (rand()%BASIC_LOOT_ID_COUNT)+1;
                lootidArr[i] = lootid;

                // loot count
                lootcount = (rand()%BASIC_LOOT_COUNT)+1;
                lootcountArr[i] = lootcount;
                
                // loot print
                switch (lootid)
                {
                    // wood
                case 1:
                    lootprint(wood,lootcount);
                    break;
                    // dirt
                case 2:
                    lootprint(dirt,lootcount);
                    break;
                    // pebbles
                case 3:
                    lootprint(pebbles,lootcount);
                    break;
                    // leaves
                case 4:
                    lootprint(leaves,lootcount);
                    break;
                default:
                    break;
                }
            }

            for (int i = 0;i < BASIC_LOOT_ID_COUNT;i++)
            {
                printf(">> ");
                fgets(input,MAX_INPUT_CHAR,stdin);
                if (charCmp(input,"c") == 0)
                {
                    
                }
                else
                {
                    break;
                }
            }
        }
        else if(charCmp(input,"cls"))
        {
            system("clear");
        }
        else if(charCmp(input,"exit"))
        {
            exit(0);
        }
    }
    return 0;
}