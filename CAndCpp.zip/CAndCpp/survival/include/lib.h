#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

// char array compare
int charCmp(char text[],char text2[]) 
{
    int len = strlen(text);
    int returntest = 0;
    int returner = 0;
    for(int i = 0;i < len;i++)
    {
        if (text[i] == text2[i])
        {
            returntest += 1;
        }
    }
    if (len == returntest + 1){
        returner = 1;
    }
    return returner;
}