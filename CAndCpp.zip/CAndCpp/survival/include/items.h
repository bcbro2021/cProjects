// basic loot
char * wood = "wood";
char * dirt = "dirt";
char * pebbles = "pebbles";
char * leaves = "leaves";

// loot print
void lootprint(char * loot,int count)
{
    printf("%sx%d\n",loot,count);
}