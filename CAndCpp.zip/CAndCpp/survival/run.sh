gcc build.c
./a.out