#include "src/window.h"

int main(int argc, char argv[])
{
    if (!Window_Init(800,600,"Window"))
    {
        printf("Failed to initialize window!\n");
        return 0;
    }
    //background
    Window_Load_Graphics_Stuff();
    Window_Color(0.07f,0.13f,0.17f,1.0f);
    Window_Swap_Buffers();

    while(Window_Is_Running())
    {
        Window_Update();
    }

    Window_Destroy();
    return 0;
}
