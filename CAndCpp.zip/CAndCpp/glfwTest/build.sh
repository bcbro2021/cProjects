gcc $(pkg-config --cflags glfw3) -o main main.c $(pkg-config --static --libs glfw3) -lGL
./main
