#ifndef WINDOW
#define WINDOW
#define GLFW_INCLUDE_NONE

#include <stdio.h>
#include <stdlib.h>
#include <GLFW/glfw3.h>
#include <GL/gl.h>

//main variables
GLFWwindow * window;
static int Window_Width = 0;
static int Window_Height = 0;

//functions
int Window_Init(int width,int height, char * title);
void update();
int Window_Is_Running();
void Window_Load_Graphics_Stuff();
void Window_Color(float w,float x,float y,float z);
void Window_Swap_Buffers()
void Window_Destroy()

//implement
// initialization
int Window_Init(int width,int height, char * title)
{
    // error check
    if (!glfwInit())
    {
        return 0;
    }

    //window itself
    glfwWindowHint(GLFW_RESIZABLE,GL_FALSE);
    window = glfwCreateWindow(width,height,title,NULL,NULL);
    Window_Width = width;
    Window_Height = height;

    //if window was not created then die, program...
    if (!window)
    {
        return 0;
    }

    glfwMakeContextCurrent(window);

    return 1;
}

//update window
void Window_Update()
{
    glfwPollEvents();
}
//is the window about to get destroyed?
int Window_Is_Running()
{
    if (!glfwWindowShouldClose(window))
    {
        return 1;
    }
    else
    {
        return 0;
    }
}
// graphics loading stuff
void Window_Load_Graphics_Stuff()
{
    glViewport(0,0,Window_Width,Window_Height);
}

//window background color
void Window_Color(float w,float x,float y,float z)
{
    glClearColor(w,x,y,z);
    glClear(GL_COLOR_BUFFER_BIT);

}

//swap buffers
void Window_Swap_Buffers()
{
    glfwSwapBuffers(window);
}

//destroy window
void Window_Destroy()
{
    glfwDestroyWindow(window);
}

#endif
