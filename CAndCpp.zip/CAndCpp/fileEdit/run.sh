gcc main.c
./a.out file.txt