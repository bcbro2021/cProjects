#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#define MAXINPUT 64
#define COMMAND_COUNT 3

bool run = true;

void help(char* commands[],char* commandTips[])
{
    for(int i = 0; i < COMMAND_COUNT;i++)
    {
        printf("%s - %s\n",commands[i],commandTips[i]);
    }
}

int main (int argc, char *argv[]) 
{
    char input[MAXINPUT];
    char* commands[COMMAND_COUNT] = {"$e","$c","$h"};
    char* commandTips[COMMAND_COUNT] = {"exits the editor","clears the file","helps you with commands"};

    while (run)
    {

        // file
        FILE *file;
        // input
        printf("> ");
        fgets(input,MAXINPUT,stdin);

        // command checking
        if (input[0] != '$')
        {
            file = fopen(argv[1],"a");
            fputs(input,file);
            fclose(file);   
        }
        // exit command
        else if (input[1] == 'e')
        {
            exit(0);
        }
        // clear command
        else if (input[1] == 'c')
        {
            file = fopen(argv[1],"w");
            fputs("",file);
            fclose(file);
        }
        // help command
        else if (input[1] == 'h')
        {
            help(commands,commandTips);
        }
        // if the command is invalid then well... umm... it will help you
        else
        {
            help(commands,commandTips);
        }        
    }
    return 0;
}