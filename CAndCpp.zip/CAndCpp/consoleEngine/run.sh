gcc main.c
./a.out