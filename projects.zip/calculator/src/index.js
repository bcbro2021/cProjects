// buttons
const number_btns = [];
const symbol_btns = [];
const equal_btn = document.getElementById("=");

const symbols = ["+","-","/","*"];

// importing number buttons
for (let i = 0;i < 10;i++) {
	let number_btn = document.getElementById(i.toString());
	number_btns.push(number_btn);
}

// import symbol buttons
for (let i = 0;i < symbols.length;i++){
	let symbol_btn = document.getElementById(symbols[i]);
	symbol_btns.push(symbol_btn);
}

// equation
var equation = "";
var equation_dis = document.getElementById("equation");

function loop() {
	requestAnimationFrame( loop );

	equation_dis.innerHTML = equation;
}

// number buttons click handling
for (let i = 0;i < number_btns.length;i++){
	number_btns[i].addEventListener('click', ()=>{
		equation += number_btns[i].innerHTML;

		console.log(equation);
	});
}

// symbol buttons click handling
for (let i = 0;i < symbol_btns.length;i++){
	symbol_btns[i].addEventListener('click', ()=>{
		equation += symbol_btns[i].innerHTML;

		console.log(equation);
	});
}

// equal button click handling
equal_btn.addEventListener('click', ()=>{
	equation = eval(equation);
	console.log(equation);
})

loop()