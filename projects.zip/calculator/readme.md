## Getting Started

### Cloning the repo

```sh
bun create blank ./NAME_HERE
```

### Execute a file (eg. src/index.js)
    
```sh
bun run ./src/index.js
```
