from ursina import *
import random, noise, sys, math

window.window_size = Vec2(1200,800)
app = Ursina()

# map stuff
map_area = (0,10)

window.exit_button.visible = False
window.color = color.rgb(244, 194, 194)

# map
cubes = []
for j in range(map_area[0],map_area[1]):
	for i in range(map_area[0],map_area[1]):
		for y in range(1):
			height = noise.pnoise2(j*0.1,i*0.1)
			cube = Entity(parent = scene,
						  model="cube",
						  position=Vec3(i,height*((i+j)*0.1),j), 
						  scale=Vec3(1,2,1),
						  texture="white_cube",
						  collider="box",
						  color = color.rgb(math.floor(255 - 5.5 * i), math.floor(255 - 5.5 * j),150),
						  highlight_color=color.lime)
			cubes.append(cube)

def input(key):
	if key == "escape":
		sys.exit()
	# generates new terrain
	if key == "q":
		for cube in cubes:
			cube.disable()
			cubes.remove(cube)
		seed = random.uniform(0.1,0.5)
		for j in range(map_area[0],map_area[1]):
			for i in range(map_area[0],map_area[1]):
				for y in range(1):
					height = noise.pnoise2(j*0.1,i*0.1)
					cube = Entity(parent = scene,
								  model="cube",
								  position=Vec3(i,height*((i+j)*seed),j), 
								  scale=Vec3(1,2,1),
								  texture="white_cube",
								  collider="box",
								  color = color.rgb(math.floor(255 - 5.5 * i), math.floor(255 - 5.5 * j),150),
								  highlight_color=color.lime)
					cubes.append(cube)

	
EditorCamera()
app.run()