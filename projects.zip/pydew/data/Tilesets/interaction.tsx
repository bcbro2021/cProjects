<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="interaction" tilewidth="64" tileheight="64" tilecount="2" columns="2">
 <image source="../../graphics/environment/interaction.png" width="128" height="64"/>
</tileset>
