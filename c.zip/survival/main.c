#include "include/lib.h"
#define MAX_INPUT_CHAR 64

int run = 1;

// main function
int main(int argc,char* argv[]) 
{
    // max input range
    char input[MAX_INPUT_CHAR];

    //loot table
    int lv1 = random(1,10);
    char * lv1Str = toArray(lv1);
    while (run) 
    {
        // input
        printf("> ");
        fgets(input,MAX_INPUT_CHAR,stdin);

        // commands
        if (charCmp(input,"loot"))
        {
            printf("loot\n");
        }
    } 
    return 0;
}