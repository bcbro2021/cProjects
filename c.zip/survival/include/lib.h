#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>

// random function
int random(int lower,int upper)
{
    srand(time(0));
    return (rand() % (upper - lower + 1)) + lower;
}

char * toArray(int number)
{
    int n = log10(number) + 1;
    int i;
    char *numberArray = calloc(n, sizeof(char));
    for (i = n-1; i >= 0; --i, number /= 10)
    {
        numberArray[i] = (number % 10) + '0';
    }
    return numberArray;
}
int charCmp(char text[],char text2[]) 
{
    int len = strlen(text);
    int returntest = 0;
    int returner = 0;
    for(int i = 0;i < len;i++)
    {
        if (text[i] == text2[i])
        {
            returntest += 1;
        }
    }
    if (len == returntest + 1){
        returner = 1;
    }
    return returner;
}